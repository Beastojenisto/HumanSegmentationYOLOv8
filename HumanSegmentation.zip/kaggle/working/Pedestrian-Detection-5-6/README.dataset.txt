# Pedestrian Detection 5 > 2023-04-01 2:46am
https://universe.roboflow.com/training-data-kgqsn/pedestrian-detection-5-prxj7

Provided by a Roboflow user
License: CC BY 4.0

